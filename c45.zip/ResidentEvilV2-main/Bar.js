class Bar {
    constructor(x, y, width, height){
        this.bar = createSprite(x, y, width, height);
        this.bar.visible = false;
        
    }

   
}